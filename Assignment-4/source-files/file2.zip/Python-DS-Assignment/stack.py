st = []

st.append(1)
st.append(2)
st.append(3)
 

print(st)
 

print(st.pop())
print(st.pop())
print(st.pop())
 

print(st)