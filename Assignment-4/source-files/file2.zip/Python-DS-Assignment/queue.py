q = []
 
q.append(1)
q.append(2)
q.append(3)
 
print(q)
 
print(q.pop(0))
print(q.pop(0))
print(q.pop(0))
 
print(q)